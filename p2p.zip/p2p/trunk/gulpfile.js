var gulp = require('gulp'); //引入gulp模块
var browserSync = require('browser-sync').create(); //引入browser-sync服务器模块，用于创建http静态服务器
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');
var less = require('gulp-less');
var css = require('gulp-clean-css');

gulp.task('default', function () {
	gulp.watch("src/js/*.js", ["uglify"]);
	gulp.watch("src/less/*.less", ["less"]);

	//开启一个静态服务器，以当前目录为网站根目录
	browserSync.init({
		server: {
			baseDir: "./"
		}
	});

	gulp.task('uglify', function () {
		//压缩js
		gulp.src('src/js/*.js').pipe(uglify()).pipe(rename(function (path) {
			path.basename += '.min';
		})).pipe(gulp.dest('dist/js'));
	});
	
	gulp.task('less', function () {
		//压缩less
		gulp.src('src/less/*.less').pipe(less()).pipe(css()).pipe(rename(function (path) {
			path.basename += '.min';
		})).pipe(gulp.dest('dist/css'));
	});

});

