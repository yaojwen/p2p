


    window.onhashchange=show;
    window.onload=show;
   
   
    function show(){
        var hash=location.hash;
        switch(hash){
           case'#/' :var filp='index';break;
           case'#/borrow': var filp='borrow';break;
           case'#/presonal':var filp='presonal';break;
           case'#/aboutUs':var filp='aboutUs';break;
           case'#/invest':var filp='invest';break;
           case'#/login':var filp='login';break;
           case'#/register':var filp='register';break;
           case'#/realAuth':var filp='realAuth';break;    
           case'#/accountflow':var filp='accountflow';break;    
           case'#/recharge':var filp='recharge';break;    
           case'#/loan_project':var filp='loan_project';break;  
           case'#/withdraw':var filp='withdraw';break;  
           case'#/userdata':var filp='userdata';break;  
           case'#/borrow_apply':var filp='borrow_apply';break;  
           case'#/borrow_info':var filp='borrow_info';break;  
           case'#/borrow_detail':var filp='borrow_detail';break;
           
         
           
           
           
        }
    
        $.get('src/comm/'+filp+'.html', function(data){
            $('#main').html(data);
            if(filp ==='presonal'){
           /*      $('#presonalname').html(`用户名：小强${$('#nowname').html()}`);    */        
                $('#presonalname').html('用户名:'+window.userid);           
            }
        });
    
        $('.nav li').click(function(){
            $(this).addClass('active').siblings().removeClass('active');
        })
    
        $('.presonalmenu a').each(function(i,v){    
            if( $(v).attr('href')==hash ){
                $(v).addClass('active');
            }else{
                 $(v).removeClass('active');
            }
         });
    
    }    


